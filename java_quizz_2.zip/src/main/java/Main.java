import org.apache.log4j.Logger;
import java.util.Random;
import java.util.Scanner;

public class Main {

    static Logger log = Logger.getLogger(Main.class.getName());
    static Random random = new Random();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int[] fibArr = fibSequence(10);

        for (int a:fibArr) {
             System.out.println("next element of fibonacci sequence is: " + a);
         }

        getFibNum(7,fibArr);

        int randomNum = getRandomMagicNum();
        guessRandomNumber(randomNum);
    }

    public static int[] fibSequence(int count) {
        int n1 = 0;
        int n2 = 1;
        int n3;
        int[] fibArr = new int[count];
        fibArr[0] = n1;
        fibArr[1] = n2;

        for (int i = 2; i < count; i++) {
            n3 = n1 + n2;
            n1 = n2;
            n2 = n3;
            log.info(n3);
            fibArr[i] = n3;
        }
        return fibArr;
    }

    public static void getFibNum(int num, int[] fibSequence) {
        int i = 0;
        while (i<num){
            i++;
            System.out.println(i);
            if (i==num-1) {
                log.info(num + "th fibonacci number is: " + fibSequence[i]);
            }

        };

    }
    public static int getRandomMagicNum() {
        int min = 14;
        int max = 1488;
        int randomNum = random.nextInt(max - min + 1) + min;
        log.info("random number generated is: " + randomNum);
        return randomNum;
    }

    public static void guessRandomNumber(int randomNumber) {
        int guess;
        boolean correct = false;
        int tries = 0;
        while (!correct) {
            tries += 1;
            System.out.print("Enter some number: ");
            guess = scanner.nextInt();
            scanner.nextLine();

            if (guess == randomNumber) {
                log.info("The number is correct. You guessed it in " + tries + " tries");
                System.out.print("Do you want to play again? y/n ");
                String ans = scanner.nextLine().toLowerCase();
                if (ans.equals("yes") || ans.equals("y")) {
                    int newRandomNum = getRandomMagicNum();
                    guessRandomNumber(newRandomNum);
                } else if (ans.equals("no") || ans.equals("n")) {
                    correct = true;
                    log.info("Morcha kino");
                }
                else {
                    log.info("incorrect option. exiting program...");
                    break;
                }
            } else if (guess < randomNumber) {
                log.info("Incorrect guess. Your number is less than the correct number. Try again");
            } else {
                log.info("Incorrect guess. Your number is greater than the correct number. Try again");
            }
        }

    }

}








