import java.util.Scanner;  // Import the Scanner class
import java.util.Arrays;
import java.util.Random;


public class Main {
    public static void main(String[] args) {
        int[] arr = new int[10];
        System.out.println("Please enter 10 integer values:");

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int[] randArr = new int[20];
        int lowerNum = 88;
        int upperNum = 145;

        System.out.println("Please enter 10 integer values:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Enter element : ");
            arr[i] = scanner.nextInt();
        }

//      print out every element of array
        System.out.println("Array contents:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Value #" + (i + 1) + ": " + arr[i]);
        }

//      input random elements in array
        for (int i = 0; i < 20; i++) {
            randArr[i] = random.nextInt((upperNum-lowerNum)) + lowerNum;
        };

//      print out every element of array
        System.out.println("Random array contents:");
        for (int i = 0; i < 20; i++) {
            System.out.println("Value #" + (i + 1) + ": " + randArr[i]);
        }

        System.out.println(findMedian(sortNums(randArr)));



        int[][] matrix1 = { { 4, 8, 19, 0 },
                            { -55, 934, 67, 1},
                            { 4, 7, 144, 88 },
                            { 0, -123, -7, 1488 } };
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j<4; j++){
                System.out.println("Value at" + (i + 1) + " " + (j+1) + " : " + matrix1[i][j]);

            }};

        int [][] matrix2 = {{43,81,1,10},
                            {-5,94,7,11},
                            {43,17,14,9},
                            {-8, 13, 7, 1}};

        // print sum of matrix elements
        System.out.println(sumMatrix(matrix2));

        // print sum of 2 matrix
        System.out.println(sumTwoMatrix(matrix1, matrix2));

        // print sum of numbers above diagonal
        System.out.println(sumAboveDiagonal(matrix2));

        // print  sum of numbers below  diagonal
        System.out.println(sumBelowDiagonal(matrix2));

        // print out sum of diagonal
        System.out.println(sumDiagonal(matrix2));


        scanner.close();

    }
    public static double findMedian(int a[])
    {
        if (a.length % 2 != 0)
            return (double)a[a.length / 2];

        return (double)(a[(a.length - 1) / 2] + a[a.length / 2]) / 2.0;
    }

    public static int[] sortNums(int a[]){
        Arrays.sort(a);

        return a;

    }

    public static int[][] sumTwoMatrix(int a[][], int b[][]){
        int[][] newMatrix = {};
        for (int i = 0; i<4; i++) {
            for (int j = 0; j<4; j++){
                newMatrix[i][j] += a[i][j] + b[i][j] ;

            }};
        return newMatrix;

    }
    public static int sumMatrix(int a[][]){
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = i; j<a.length; j++){
                sum += a[i][j];

            }};
        return sum;

    }

    public static int sumAboveDiagonal(int a[][]){
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = i+1; j<a.length; j++){
                sum += a[i][j];

            }};
        return sum;

    }
    public static int sumBelowDiagonal(int a[][]){
        int sum = 0;
        for (int i = 1; i < a.length; i++) {
            for (int j = 0; j<i; j++){
                sum += a[i][j];

            }};
        return sum;

    }
    public static int sumDiagonal(int a[][]){
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
                sum += a[i][i];

            };
        return sum;

    }





}

